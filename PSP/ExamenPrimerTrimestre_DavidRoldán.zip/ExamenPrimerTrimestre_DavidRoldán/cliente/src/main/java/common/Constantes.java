package common;

public class Constantes {
    public static final String CONFIG_PROPERTIES = "config.properties";
    public static final String PATH_DATOS = "pathDatos";
    public static final String LOGIN = "login";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String ERROR_DE_COMUNICACION = "Error de comunicacion";
    public static final String APPLICATION_JSON = "application/json";
    public static final String OK = "OK";

    private Constantes() {
    }
}
