package domain.servicios.impl;

import dao.DaoAsignaturas;
import domain.error.ErrorCliente;
import domain.modelo.Asignatura;
import domain.servicios.ServiciosAsignaturas;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

public class ServiciosAsignaturasImpl implements ServiciosAsignaturas {
    private final DaoAsignaturas dao;

    @Inject
    public ServiciosAsignaturasImpl(DaoAsignaturas dao) {
        this.dao = dao;
    }

    @Override
    public Single<Either<ErrorCliente, Asignatura>> saveAsignatura(Asignatura a) {
        if (a.getDificultad() < 1 || a.getDificultad() > 5){
            return Single.just(Either.left(new ErrorCliente("La dificultad debe estar entre 1 y 5")));
        }
        return dao.saveAsignatura(a);
    }
}
