package domain.servicios;

import domain.error.ErrorCliente;
import domain.modelo.Examen;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;

import java.util.List;

public interface ServiciosExamenes {
    Single<Either<ErrorCliente, List<Examen>>> getExamenesPublicadosAsignatura(int id);
    Single<Either<ErrorCliente, List<Examen>>> getExamenesAsignatura(int id);
    Single<Either<ErrorCliente, Examen>> updateEstado(int id);
    Single<Either<ErrorCliente, String>> deleteExamenesAsignatura(int id);
}
