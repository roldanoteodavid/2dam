package domain.servicios.impl;

import dao.DaoExamenes;
import domain.error.ErrorCliente;
import domain.modelo.Examen;
import domain.servicios.ServiciosExamenes;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

import java.util.List;

public class ServiciosExamenesImpl implements ServiciosExamenes {
    private final DaoExamenes dao;

    @Inject
    public ServiciosExamenesImpl(DaoExamenes dao){
        this.dao = dao;
    }

    @Override
    public Single<Either<ErrorCliente, List<Examen>>> getExamenesPublicadosAsignatura(int id) {
        return dao.getExamenesPublicadosAsignatura(id);
    }

    @Override
    public Single<Either<ErrorCliente, List<Examen>>> getExamenesAsignatura(int id) {
        return dao.getExamenesAsignatura(id);
    }

    @Override
    public Single<Either<ErrorCliente, Examen>> updateEstado(int id) {
        return dao.updateEstado(id);
    }

    @Override
    public Single<Either<ErrorCliente, String>> deleteExamenesAsignatura(int id) {
        return dao.deleteExamenesAsignatura(id);
    }
}
