package domain.servicios.impl;

import dao.DaoLogin;
import domain.error.ErrorCliente;
import domain.modelo.Profesor;
import domain.servicios.ServiciosLogin;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

public class ServiciosLoginImpl implements ServiciosLogin {
    private DaoLogin dao;

    @Inject
    public ServiciosLoginImpl(DaoLogin dao) {
        this.dao = dao;
    }

    @Override
    public Single<Either<ErrorCliente, String>> doLogin(String nombre, String password) {
        return dao.doLogin(nombre, password);
    }

    @Override
    public Single<Either<ErrorCliente, Profesor>> saveProfesor(Profesor profesor) {
        return dao.saveProfesor(profesor);
    }
}
