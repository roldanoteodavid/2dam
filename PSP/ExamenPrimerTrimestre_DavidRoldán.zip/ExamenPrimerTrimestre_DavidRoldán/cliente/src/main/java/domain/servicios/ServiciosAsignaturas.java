package domain.servicios;

import domain.error.ErrorCliente;
import domain.modelo.Asignatura;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;

public interface ServiciosAsignaturas {
    Single<Either<ErrorCliente, Asignatura>> saveAsignatura(Asignatura asignatura);
}
