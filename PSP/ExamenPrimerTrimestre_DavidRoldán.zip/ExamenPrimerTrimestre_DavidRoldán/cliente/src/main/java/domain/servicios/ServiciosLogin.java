package domain.servicios;

import domain.error.ErrorCliente;
import domain.modelo.Profesor;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;

public interface ServiciosLogin {
    Single<Either<ErrorCliente, String>> doLogin(String nombre, String password);
    Single<Either<ErrorCliente, Profesor>> saveProfesor(Profesor profesor);
}
