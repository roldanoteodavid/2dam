package domain.servicios.impl;

import dao.DaoPreguntas;
import domain.error.ErrorCliente;
import domain.modelo.Pregunta;
import domain.servicios.ServiciosPreguntas;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

import java.util.List;

public class ServiciosPreguntasImpl implements ServiciosPreguntas {
    private final DaoPreguntas dao;

    @Inject
    public ServiciosPreguntasImpl(DaoPreguntas dao) {
        this.dao = dao;
    }

    @Override
    public Single<Either<ErrorCliente, List<Pregunta>>> getPreguntas() {
        return dao.getPreguntas();
    }

    @Override
    public Single<Either<ErrorCliente, Pregunta>> savePregunta(Pregunta p) {
        if (p.getValor()<1 || p.getValor()>10){
            return Single.just(Either.left(new ErrorCliente("El valor de la pregunta tiene que estar entre 1 y 10")));
        }
        return dao.savePregunta(p);
    }

    @Override
    public Single<Either<ErrorCliente, Pregunta>> updatePregunta(Pregunta pregunta) {
        return dao.updatePregunta(pregunta);
    }

    @Override
    public Single<Either<ErrorCliente, String>> deletePregunta(int id) {
        return dao.deletePregunta(id);
    }

}
