package dao.retrofit.llamadas;

import domain.modelo.Pregunta;
import io.reactivex.rxjava3.core.Single;
import retrofit2.Response;
import retrofit2.http.*;

import java.util.List;

public interface PreguntasApi {

    @GET("preguntas")
    Single<List<Pregunta>> getPreguntas();

    @POST("preguntas")
    Single<Pregunta> addPregunta(@Body Pregunta pregunta);

    @PUT("preguntas")
    Single<Pregunta> updatePregunta(@Body Pregunta pregunta);

    @DELETE("preguntas" + "/{id}")
    Single<Response<Void>> deleteDirector(@Path("id") int id);
}