package dao.impl;

import com.google.gson.Gson;
import dao.DaoPreguntas;
import dao.retrofit.llamadas.PreguntasApi;
import domain.error.ErrorCliente;
import domain.modelo.Pregunta;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

import java.util.List;

public class DaoPreguntasImpl extends DaoGenerics implements DaoPreguntas {

    private final PreguntasApi preguntasApi;

    @Inject
    public DaoPreguntasImpl(PreguntasApi preguntasApi, Gson gson){
        super(gson);
        this.preguntasApi = preguntasApi;
    }

    @Override
    public Single<Either<ErrorCliente, List<Pregunta>>> getPreguntas() {
        return safeSingleApicall(preguntasApi.getPreguntas());
    }

    @Override
    public Single<Either<ErrorCliente, Pregunta>> savePregunta(Pregunta pregunta) {
        return safeSingleApicall(preguntasApi.addPregunta(pregunta));
    }

    @Override
    public Single<Either<ErrorCliente, Pregunta>> updatePregunta(Pregunta pregunta) {
        return safeSingleApicall(preguntasApi.updatePregunta(pregunta));
    }

    @Override
    public Single<Either<ErrorCliente, String>> deletePregunta(int id) {
        return safeSingleVoidApicall(preguntasApi.deleteDirector(id));
    }
}
