package dao.impl;

import com.google.gson.Gson;
import dao.DaoAsignaturas;
import dao.retrofit.llamadas.AsignaturasApi;
import domain.error.ErrorCliente;
import domain.modelo.Asignatura;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

public class DaoAsignaturasImpl extends DaoGenerics implements DaoAsignaturas {

    private final AsignaturasApi asignaturasApi;

    @Inject
    public DaoAsignaturasImpl(AsignaturasApi asignaturasApi, Gson gson){
        super(gson);
        this.asignaturasApi = asignaturasApi;
    }
    @Override
    public Single<Either<ErrorCliente, Asignatura>> saveAsignatura(Asignatura asignatura) {
        return safeSingleApicall(asignaturasApi.addAsignatura(asignatura));
    }
}
