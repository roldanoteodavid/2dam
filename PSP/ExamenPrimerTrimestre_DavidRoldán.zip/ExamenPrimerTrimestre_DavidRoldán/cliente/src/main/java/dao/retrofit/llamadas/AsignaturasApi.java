package dao.retrofit.llamadas;

import domain.modelo.Asignatura;
import io.reactivex.rxjava3.core.Single;
import retrofit2.http.*;


public interface AsignaturasApi {

    @POST("asignaturas")
    Single<Asignatura> addAsignatura(@Body Asignatura asignatura);
}