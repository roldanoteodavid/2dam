package dao;

import domain.error.ErrorCliente;
import domain.modelo.Pregunta;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;

import java.util.List;

public interface DaoPreguntas {
    Single<Either<ErrorCliente, List<Pregunta>>> getPreguntas();

    Single<Either<ErrorCliente, Pregunta>> savePregunta(Pregunta pregunta);

    Single<Either<ErrorCliente, Pregunta>> updatePregunta(Pregunta pregunta);

    Single<Either<ErrorCliente, String>> deletePregunta(int id);
}
