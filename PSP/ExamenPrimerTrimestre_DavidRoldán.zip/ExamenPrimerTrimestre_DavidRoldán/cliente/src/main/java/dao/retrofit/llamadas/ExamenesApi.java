package dao.retrofit.llamadas;

import domain.modelo.Examen;
import io.reactivex.rxjava3.core.Single;
import retrofit2.Response;
import retrofit2.http.*;

import java.util.List;

public interface ExamenesApi {

    @GET("examenes"+"/{id}")
    Single<List<Examen>> getExamenesPublicadosAsignatura(@Path("id") int id);

    @GET("examenes/profesor" + "/{id}")
    Single<List<Examen>> getExamenesAsignatura(@Path("id") int id);


    @PUT("examenes/profesor" + "/{id}")
    Single<Examen> updateEstado(@Path("id") int id);

    @DELETE("examenes/profesor" + "/{id}")
    Single<Response<Void>> deleteExamenesAsignatura(@Path("id") int id);
}