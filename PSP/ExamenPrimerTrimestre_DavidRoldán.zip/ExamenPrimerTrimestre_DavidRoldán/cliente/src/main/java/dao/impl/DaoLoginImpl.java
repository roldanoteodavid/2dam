package dao.impl;

import com.google.gson.Gson;
import dao.DaoLogin;
import dao.retrofit.llamadas.LoginApi;
import domain.error.ErrorCliente;
import domain.modelo.Profesor;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

public class DaoLoginImpl extends DaoGenerics implements DaoLogin {

    private final LoginApi loginApi;

    @Inject
    public DaoLoginImpl(LoginApi loginApi, Gson gson){
        super(gson);
        this.loginApi = loginApi;
    }

    @Override
    public Single<Either<ErrorCliente, String>> doLogin(String nombre, String password) {
        return safeSingleVoidApicall(loginApi.doLogin(nombre, password));
    }

    @Override
    public Single<Either<ErrorCliente, Profesor>> saveProfesor(Profesor profesor) {
        return safeSingleApicall(loginApi.postProfesor(profesor));
    }
}
