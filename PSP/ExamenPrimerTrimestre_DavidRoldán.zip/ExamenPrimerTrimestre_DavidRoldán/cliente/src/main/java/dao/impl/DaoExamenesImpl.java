package dao.impl;

import com.google.gson.Gson;
import dao.DaoExamenes;
import dao.retrofit.llamadas.ExamenesApi;
import domain.error.ErrorCliente;
import domain.modelo.Examen;
import io.reactivex.rxjava3.core.Single;
import io.vavr.control.Either;
import jakarta.inject.Inject;

import java.util.List;

public class DaoExamenesImpl extends DaoGenerics implements DaoExamenes {

    private final ExamenesApi examenesApi;

    @Inject
    public DaoExamenesImpl(ExamenesApi examenesApi, Gson gson) {
        super(gson);
        this.examenesApi = examenesApi;
    }

    @Override
    public Single<Either<ErrorCliente, List<Examen>>> getExamenesPublicadosAsignatura(int id) {
        return safeSingleApicall(examenesApi.getExamenesPublicadosAsignatura(id));
    }

    @Override
    public Single<Either<ErrorCliente, List<Examen>>> getExamenesAsignatura(int id) {
        return safeSingleApicall(examenesApi.getExamenesAsignatura(id));
    }

    @Override
    public Single<Either<ErrorCliente, Examen>> updateEstado(int id) {
        return safeSingleApicall(examenesApi.updateEstado(id));
    }

    @Override
    public Single<Either<ErrorCliente, String>> deleteExamenesAsignatura(int id) {
        return safeSingleVoidApicall(examenesApi.deleteExamenesAsignatura(id));
    }
}
