package ui;

import domain.modelo.Pregunta;
import domain.servicios.ServiciosLogin;
import domain.servicios.ServiciosPreguntas;
import io.reactivex.rxjava3.schedulers.Schedulers;
import jakarta.enterprise.inject.se.SeContainer;
import jakarta.enterprise.inject.se.SeContainerInitializer;

public class Ej5 {


    public static void main(String[] args) {
        SeContainerInitializer initializer = SeContainerInitializer.newInstance();
        final SeContainer container = initializer.initialize();

        ServiciosLogin serviciosLogin = container.select(ServiciosLogin.class).get();
        ServiciosPreguntas serviciosPreguntas = container.select(ServiciosPreguntas.class).get();

        serviciosLogin.doLogin("David", "2dam")
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });

        serviciosPreguntas.deletePregunta(1)
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });
    }
}
