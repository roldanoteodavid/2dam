package ui;

import domain.modelo.Asignatura;
import domain.servicios.ServiciosAsignaturas;
import domain.servicios.ServiciosLogin;
import io.reactivex.rxjava3.schedulers.Schedulers;
import jakarta.enterprise.inject.se.SeContainer;
import jakarta.enterprise.inject.se.SeContainerInitializer;

public class Ej1 {


    public static void main(String[] args) {
        SeContainerInitializer initializer = SeContainerInitializer.newInstance();
        final SeContainer container = initializer.initialize();

        ServiciosLogin serviciosLogin = container.select(ServiciosLogin.class).get();
        ServiciosAsignaturas serviciosAsignaturas = container.select(ServiciosAsignaturas.class).get();

        serviciosLogin.doLogin("David", "2dam")
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });


        serviciosAsignaturas.saveAsignatura(new Asignatura(8, "Asignatura4", 5, 1, "David"))
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });

        serviciosAsignaturas.saveAsignatura(new Asignatura(8, "Asignatura4", 5, 10, "David"))
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });

        serviciosAsignaturas.saveAsignatura(new Asignatura(8, "Asignatura4", 5, 3, "Óscar"))
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });
    }
}
