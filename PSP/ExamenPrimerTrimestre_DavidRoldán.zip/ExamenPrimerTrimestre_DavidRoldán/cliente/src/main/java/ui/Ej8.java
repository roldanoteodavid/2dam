package ui;

import domain.servicios.ServiciosLogin;
import domain.servicios.ServiciosPreguntas;
import io.reactivex.rxjava3.schedulers.Schedulers;
import jakarta.enterprise.inject.se.SeContainer;
import jakarta.enterprise.inject.se.SeContainerInitializer;

public class Ej8 {


    public static void main(String[] args) {
        SeContainerInitializer initializer = SeContainerInitializer.newInstance();
        final SeContainer container = initializer.initialize();
        ServiciosPreguntas serviciosPreguntas = container.select(ServiciosPreguntas.class).get();

        serviciosPreguntas.getPreguntas()
                .subscribeOn(Schedulers.io())
                .blockingSubscribe(either -> {
                    if (either.isRight()){
                        System.out.println(either.get());
                    } else if (either.isLeft()){
                        System.out.println(either.getLeft());
                    }
                });
    }
}
