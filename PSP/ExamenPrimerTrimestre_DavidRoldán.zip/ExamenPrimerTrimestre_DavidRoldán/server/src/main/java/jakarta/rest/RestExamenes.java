package jakarta.rest;

import domain.modelo.Examen;
import domain.servicios.ServiciosExamenes;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/examenes")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RestExamenes {
    private final ServiciosExamenes serviciosExamenes;

    @Inject
    public RestExamenes(ServiciosExamenes serviciosExamenes){
        this.serviciosExamenes = serviciosExamenes;
    }

    @GET
    @Path("/{id}")
    public List<Examen> getExamenesPublicadosAsignatura(@PathParam("id") int id){
        return serviciosExamenes.getExamenesPublicadosAsignatura(id);
    }

    @GET
    @Path("profesor"+"/{id}")
    public List<Examen> getExamenesAsignatura(@PathParam("id") int id){
        return serviciosExamenes.getExamenesAsignatura(id);
    }

    @PUT
    @Path("/profesor"+"/{id}")
    public Examen updateEstado(@PathParam("id") int id){
        return serviciosExamenes.updateEstado(id);
    }

    @DELETE
    @Path("/profesor"+"/{id}")
    public Response deleteExamenesAsignatura(@PathParam("id") int id){
        serviciosExamenes.deleteExamenesAsignatura(id);
        return Response.status(Response.Status.NO_CONTENT).build();
    }
}
