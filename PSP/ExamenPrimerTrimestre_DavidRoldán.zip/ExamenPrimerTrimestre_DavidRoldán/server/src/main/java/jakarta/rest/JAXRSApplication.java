package jakarta.rest;


import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath(ConstantesJakarta.API)
public class JAXRSApplication extends Application {

}
