package jakarta.rest;

public class ConstantesJakarta {
    public static final String API = "/api";

    private ConstantesJakarta() {
    }
}
