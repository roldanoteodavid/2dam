package jakarta.rest;

import domain.modelo.Asignatura;
import domain.servicios.ServiciosAsignaturas;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/asignaturas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RestAsignaturas {
    private final ServiciosAsignaturas serviciosAsignaturas;

    @Inject
    public RestAsignaturas(ServiciosAsignaturas serviciosAsignaturas){
        this.serviciosAsignaturas = serviciosAsignaturas;
    }

    @POST
    public Response addAsignatura(Asignatura asignatura){
        serviciosAsignaturas.save(asignatura);
        return Response.status(Response.Status.CREATED).entity(asignatura).build();
    }
}
