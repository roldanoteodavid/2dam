package jakarta.rest;

import domain.modelo.Profesor;
import domain.servicios.ServiciosLogin;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/login")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RestLogin {
    private final HttpServletRequest request;
    private final ServiciosLogin serviciosLogin;

    @Inject
    public RestLogin(ServiciosLogin serviciosLogin, HttpServletRequest request){
        this.request = request;
        this.serviciosLogin = serviciosLogin;
    }

    @GET
    public Response doLogin(@QueryParam("username") String user, @QueryParam("password") String password) {
        boolean result = serviciosLogin.doLogin(user, password);
        request.getSession().setAttribute("LOGIN", null);
        if (result) {
            request.getSession().setAttribute("LOGIN", true);
            return Response.status(Response.Status.NO_CONTENT).build();
        } else {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

    }

    @PUT
    public Response addProfesor(Profesor profesor){
        if (serviciosLogin.save(profesor)){
            return Response.status(Response.Status.CREATED).entity(profesor).build();
        }else {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }
    }
}
