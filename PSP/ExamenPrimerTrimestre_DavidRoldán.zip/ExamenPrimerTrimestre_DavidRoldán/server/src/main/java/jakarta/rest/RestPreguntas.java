package jakarta.rest;

import domain.modelo.Pregunta;
import domain.servicios.ServiciosPreguntas;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/preguntas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RestPreguntas {
    private final ServiciosPreguntas serviciosPreguntas;

    @Inject
    public RestPreguntas(ServiciosPreguntas serviciosPreguntas){
        this.serviciosPreguntas = serviciosPreguntas;
    }

    @GET
    public List<Pregunta> getAllPreguntas(){
        return serviciosPreguntas.getAll();
    }

    @POST
    public Response addPregunta(Pregunta pregunta){
        serviciosPreguntas.save(pregunta);
        return Response.status(Response.Status.CREATED).entity(pregunta).build();
    }

    @PUT
    public Pregunta updatePregunta(Pregunta pregunta){
        return serviciosPreguntas.update(pregunta);
    }

    @DELETE
    @Path("/{id}")
    public Response deletePregunta(@PathParam("id") int id){
        serviciosPreguntas.delete(id);
        return Response.status(Response.Status.NO_CONTENT).build();
    }
}
