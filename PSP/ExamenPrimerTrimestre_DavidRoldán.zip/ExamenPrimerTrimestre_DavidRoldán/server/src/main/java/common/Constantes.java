package common;

public class Constantes {

    private Constantes() {
    }
}
