package dao.data;

import domain.modelo.Asignatura;
import domain.modelo.Examen;
import domain.modelo.Pregunta;
import domain.modelo.Profesor;

import java.util.ArrayList;
import java.util.List;

public class StaticLists {

    public static final List<Profesor> profesoresList = new ArrayList<>(List.of(
            new Profesor("David", "PBKDF2WithHmacSHA256:2048:zhs5nnWejmpUjNSlzm3NdGpITFipP/uwd++xk9OZZ3o=:joup3DdZ171OxkhnNFUC+A+VJCp7nMpQtw0sRKPwn2w="),
            new Profesor("Óscar", "PBKDF2WithHmacSHA256:2048:zhs5nnWejmpUjNSlzm3NdGpITFipP/uwd++xk9OZZ3o=:joup3DdZ171OxkhnNFUC+A+VJCp7nMpQtw0sRKPwn2w=")
    ));

    public static final List<Asignatura> asignaturaList = new ArrayList<>(List.of(
            new Asignatura(1, "PSP", 5, 4, "Óscar"),
            new Asignatura(2, "Móviles", 4, 3, "Óscar"),
            new Asignatura(3, "Asignatura3", 2, 1, "Óscar"),
            new Asignatura(4, "Asignatura4", 3, 3, "Óscar"),
            new Asignatura(5, "Asignatura5", 3, 2, "David")
    ));

    public static final List<Examen> examenList = new ArrayList<>(List.of(
            new Examen(1, "En desarrollo", "29/10/2022", 1, new ArrayList<>(List.of(new Pregunta(1, "pregunta1", 5), new Pregunta(2, "pregunta2", 1)))),
            new Examen(2, "En desarrollo", "29/10/2022", 1, new ArrayList<>(List.of(new Pregunta(1, "pregunta1", 5), new Pregunta(5, "pregunta5", 5)))),
            new Examen(3, "Publicado", "30/11/2023", 2, new ArrayList<>(List.of(new Pregunta(3, "pregunta3", 3), new Pregunta(5, "pregunta5", 5),
                    new Pregunta(4, "pregunta4", 2))))
    ));


    public static final List<Pregunta> preguntasList = new ArrayList<>(List.of(
            new Pregunta(1, "pregunta1", 1),
            new Pregunta(2, "pregunta2", 5),
            new Pregunta(3, "pregunta3", 3),
            new Pregunta(4, "pregunta4", 2),
            new Pregunta(4, "pregunta5", 5)
    ));

    private StaticLists() {
    }
}
