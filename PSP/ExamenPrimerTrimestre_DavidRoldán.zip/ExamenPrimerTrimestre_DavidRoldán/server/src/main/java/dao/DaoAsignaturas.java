package dao;

import domain.modelo.Asignatura;

import java.util.List;

public interface DaoAsignaturas {
    List<Asignatura> getAsignaturasProfesor(String nombre);
    boolean save(Asignatura a);
}
