package dao;

import domain.modelo.Profesor;

public interface DaoLogin {
    Profesor get(String nombre);
    boolean save(Profesor p);
}
