package dao.impl;

import dao.DaoLogin;
import dao.data.StaticLists;
import domain.modelo.Profesor;
import domain.modelo.errores.NotFoundException;

public class DaoLoginImpl implements DaoLogin {
    @Override
    public Profesor get(String nombre) {
        Profesor profesor = StaticLists.profesoresList.stream().filter(prof -> prof.getNombre().equals(nombre)).findFirst().orElse(null);
        if (profesor==null){
            throw new NotFoundException("Profesor no encontrado");
        }
        return profesor;
    }

    @Override
    public boolean save(Profesor p) {
        return StaticLists.profesoresList.add(p);
    }
}
