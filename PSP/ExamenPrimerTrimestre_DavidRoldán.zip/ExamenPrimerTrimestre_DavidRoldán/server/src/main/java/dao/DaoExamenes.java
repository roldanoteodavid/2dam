package dao;

import domain.modelo.Examen;

import java.util.List;

public interface DaoExamenes {
    List<Examen> getExamenesPublicadosAsignatura(int id);
    List<Examen> getExamenesAsignatura(int id);
    Examen get(int id);
    Examen updateEstado(int id);
    boolean deleteExamenesAsignatura(int idAsignatura);

}
