package dao.impl;

import dao.DaoExamenes;
import dao.data.StaticLists;
import domain.modelo.Examen;
import domain.modelo.errores.NotFoundException;

import java.util.List;

public class DaoExamenesImpl implements DaoExamenes {
    @Override
    public List<Examen> getExamenesPublicadosAsignatura(int id) {
        return StaticLists.examenList.stream().filter(examen -> examen.getEstado().equals("Publicado") && examen.getIdAsignatura()==id).toList();
    }

    @Override
    public List<Examen> getExamenesAsignatura(int id) {
        return StaticLists.examenList.stream().filter(examen -> examen.getIdAsignatura()==id).toList();
    }

    @Override
    public Examen get(int id) {
        return StaticLists.examenList.stream().filter(examen -> examen.getId()==id).findFirst().orElse(null);
    }

    @Override
    public Examen updateEstado(int id) {
        Examen examenupdate = StaticLists.examenList.stream().filter(examen -> examen.getId()==id).findFirst().orElse(null);
        if (examenupdate==null){
            throw new NotFoundException("Examen no encontrado");
        }
        examenupdate.setEstado("Publicado");
        return examenupdate;
    }

    @Override
    public boolean deleteExamenesAsignatura(int idAsignatura) {
        List<Examen> examenesDelete = StaticLists.examenList.stream().filter(examen -> examen.getIdAsignatura()==idAsignatura).toList();
        return StaticLists.examenList.removeAll(examenesDelete);
    }
}
