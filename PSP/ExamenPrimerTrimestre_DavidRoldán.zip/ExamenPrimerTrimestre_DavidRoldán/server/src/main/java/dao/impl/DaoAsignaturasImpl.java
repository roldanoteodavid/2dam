package dao.impl;

import dao.DaoAsignaturas;
import dao.data.StaticLists;
import domain.modelo.Asignatura;
import domain.modelo.Profesor;
import domain.modelo.errores.NotFoundException;

import java.util.List;

public class DaoAsignaturasImpl implements DaoAsignaturas {

    @Override
    public List<Asignatura> getAsignaturasProfesor(String nombre) {
        return StaticLists.asignaturaList.stream().filter(asignatura -> asignatura.getNombreProfesor().equals(nombre)).toList();
    }

    @Override
    public boolean save(Asignatura a) {
        Profesor profesor = StaticLists.profesoresList.stream().filter(profesor1 -> profesor1.getNombre().equals(a.getNombreProfesor())).findFirst().orElse(null);
        if (profesor == null) {
            throw new NotFoundException("El profesor indicado no existe");
        }
        return StaticLists.asignaturaList.add(a);
    }
}
