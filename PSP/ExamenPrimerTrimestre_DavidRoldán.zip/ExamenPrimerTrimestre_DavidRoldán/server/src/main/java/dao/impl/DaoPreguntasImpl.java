package dao.impl;

import dao.DaoPreguntas;
import dao.data.StaticLists;
import domain.modelo.Pregunta;
import domain.modelo.errores.NotFoundException;

import java.util.List;

public class DaoPreguntasImpl implements DaoPreguntas {
    @Override
    public List<Pregunta> getAll() {
        return StaticLists.preguntasList;
    }

    @Override
    public boolean save(Pregunta p) {
        return StaticLists.preguntasList.add(p);
    }

    @Override
    public Pregunta update(Pregunta p) {
        Pregunta preguntadelete = StaticLists.preguntasList.stream().filter(pregunta -> pregunta.getId()==p.getId()).findFirst().orElse(null);
        if (preguntadelete==null){
            throw new NotFoundException("Asignatura no encontrada");
        }
        int index = StaticLists.preguntasList.indexOf(preguntadelete);
        StaticLists.preguntasList.set(index, p);
        return p;
    }

    @Override
    public boolean delete(int id) {
        Pregunta preguntadelete = StaticLists.preguntasList.stream().filter(pregunta -> pregunta.getId()==id).findFirst().orElse(null);
        if (preguntadelete==null){
            throw new NotFoundException("Asignatura no encontrada");
        }
        return StaticLists.preguntasList.remove(preguntadelete);
    }
}
