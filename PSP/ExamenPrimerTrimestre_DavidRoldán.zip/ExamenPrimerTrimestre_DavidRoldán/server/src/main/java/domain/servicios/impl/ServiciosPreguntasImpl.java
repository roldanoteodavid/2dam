package domain.servicios.impl;

import dao.DaoPreguntas;
import domain.modelo.Pregunta;
import domain.modelo.errores.InvalidFieldException;
import domain.servicios.ServiciosPreguntas;
import jakarta.inject.Inject;

import java.util.List;

public class ServiciosPreguntasImpl implements ServiciosPreguntas {
    private final DaoPreguntas dao;

    @Inject
    public ServiciosPreguntasImpl(DaoPreguntas dao){
        this.dao = dao;
    }

    @Override
    public List<Pregunta> getAll() {
        return dao.getAll();
    }

    @Override
    public boolean save(Pregunta p) {
        validarValor(p);
        return dao.save(p);
    }

    @Override
    public Pregunta update(Pregunta p) {
        validarValor(p);
        return dao.update(p);
    }

    @Override
    public boolean delete(int id) {
        return dao.delete(id);
    }

    private void validarValor(Pregunta p){
        if (p.getValor()<1 || p.getValor()>10){
            throw new InvalidFieldException("El valor de la pregunta tiene que estar entre 1 y 10");
        }
    }
}
