package domain.servicios;

import domain.modelo.Examen;

import java.util.List;

public interface ServiciosExamenes {
    List<Examen> getExamenesPublicadosAsignatura(int id);
    List<Examen> getExamenesAsignatura(int id);
    Examen updateEstado(int id);
    boolean deleteExamenesAsignatura(int idAsignatura);
}
