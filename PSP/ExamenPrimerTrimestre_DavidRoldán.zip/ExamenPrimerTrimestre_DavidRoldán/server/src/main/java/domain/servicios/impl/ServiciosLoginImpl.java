package domain.servicios.impl;

import dao.DaoLogin;
import domain.modelo.Profesor;
import domain.modelo.errores.ValidationException;
import domain.servicios.ServiciosLogin;
import jakarta.inject.Inject;
import jakarta.security.enterprise.identitystore.Pbkdf2PasswordHash;

public class ServiciosLoginImpl implements ServiciosLogin {
    private final DaoLogin dao;
    private final Pbkdf2PasswordHash passwordHash;

    @Inject
    public ServiciosLoginImpl(DaoLogin dao, Pbkdf2PasswordHash passwordHash){
        this.dao = dao;
        this.passwordHash = passwordHash;
    }



    @Override
    public boolean doLogin(String nombre, String password) {
        boolean result = false;
        if (nombre==null || password==null){
            throw new ValidationException("User or password is empty");
        }else {
            Profesor profesor = dao.get(nombre);
            result = passwordHash.verify(password.toCharArray(), profesor.getPassword());
        }
        return result;
    }

    @Override
    public boolean save(Profesor p) {
        String password = passwordHash.generate(p.getPassword().toCharArray());
        p.setPassword(password);
        return dao.save(p);
    }
}
