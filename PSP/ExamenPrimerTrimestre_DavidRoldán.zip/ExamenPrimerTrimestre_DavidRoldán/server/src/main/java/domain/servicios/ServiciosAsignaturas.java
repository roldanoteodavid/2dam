package domain.servicios;

import domain.modelo.Asignatura;

public interface ServiciosAsignaturas {
    boolean save(Asignatura a);
}
