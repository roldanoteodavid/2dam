package domain.servicios.impl;

import dao.DaoExamenes;
import domain.modelo.Examen;
import domain.modelo.errores.InvalidFieldException;
import domain.servicios.ServiciosExamenes;
import jakarta.inject.Inject;

import java.util.List;

public class ServiciosExamenesImpl implements ServiciosExamenes {
    private final DaoExamenes dao;

    @Inject
    public ServiciosExamenesImpl(DaoExamenes dao) {
        this.dao = dao;
    }

    @Override
    public List<Examen> getExamenesPublicadosAsignatura(int id) {
        return dao.getExamenesPublicadosAsignatura(id);
    }

    @Override
    public List<Examen> getExamenesAsignatura(int id) {
        return dao.getExamenesAsignatura(id);
    }

    @Override
    public Examen updateEstado(int id) {
        validarValor(id);
        return dao.updateEstado(id);
    }

    @Override
    public boolean deleteExamenesAsignatura(int idAsignatura) {
        return dao.deleteExamenesAsignatura(idAsignatura);
    }

    private void validarValor(int id) {
        Examen examen = dao.get(id);
        int valortotal = 0;
        for (int i = 0; i < examen.getPreguntas().size(); i++) {
            valortotal = valortotal + examen.getPreguntas().get(i).getValor();
        }
        if (valortotal!=10){
            throw new InvalidFieldException("El valor total de las preguntas del examen indicado no es de 10");
        }
    }
}
