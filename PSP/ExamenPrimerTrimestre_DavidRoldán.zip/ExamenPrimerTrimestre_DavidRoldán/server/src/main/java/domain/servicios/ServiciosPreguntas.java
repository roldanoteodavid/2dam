package domain.servicios;

import domain.modelo.Pregunta;

import java.util.List;

public interface ServiciosPreguntas {
    List<Pregunta> getAll();
    boolean save(Pregunta p);
    Pregunta update(Pregunta p);
    boolean delete(int id);
}
