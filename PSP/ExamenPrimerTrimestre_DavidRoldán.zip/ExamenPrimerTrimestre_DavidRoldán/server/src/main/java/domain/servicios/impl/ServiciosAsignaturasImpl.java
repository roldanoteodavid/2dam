package domain.servicios.impl;

import dao.DaoAsignaturas;
import domain.modelo.Asignatura;
import domain.modelo.errores.InvalidFieldException;
import domain.servicios.ServiciosAsignaturas;
import jakarta.inject.Inject;

public class ServiciosAsignaturasImpl implements ServiciosAsignaturas {
    private final DaoAsignaturas dao;

    @Inject
    public ServiciosAsignaturasImpl(DaoAsignaturas dao) {
        this.dao = dao;
    }

    @Override
    public boolean save(Asignatura a) {
        validarDificultad(a);
        validarProfesor(a);
        return dao.save(a);
    }

    private void validarDificultad(Asignatura a) {
        if (a.getDificultad() < 1 || a.getDificultad() > 5) {
            throw new InvalidFieldException("La dificultad debe estar entre 1 y 5");
        }
    }

    private void validarProfesor(Asignatura a){
        if (dao.getAsignaturasProfesor(a.getNombreProfesor()).size()>=4){
            throw new InvalidFieldException("Un profesor no puede tener más de 4 asignaturas");
        }
    }
}
