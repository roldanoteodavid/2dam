package domain.servicios;

import domain.modelo.Profesor;

public interface ServiciosLogin {
    boolean doLogin(String nombre, String password);
    boolean save(Profesor p);
}
