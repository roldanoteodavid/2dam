package domain.modelo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Examen {
    private int id;
    private String estado;
    private String fechaPublicacion;
    private int idAsignatura;
    private List<Pregunta> preguntas;
}
