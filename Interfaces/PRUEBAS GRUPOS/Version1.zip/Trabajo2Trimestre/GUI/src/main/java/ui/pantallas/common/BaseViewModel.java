package ui.pantallas.common;

public class BaseViewModel {
}
