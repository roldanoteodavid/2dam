package ui.pantallas.common;

public class ConstantesPantallas {

    public static final String ELEGIR_PARTIDA = "/fxml/load.fxml";
    public static final String WELCOME = "/fxml/welcome.fxml";
    public static final String JUGAR = "/fxml/juego.fxml";
    public static final String SAVE = "/fxml/save.fxml";
}
