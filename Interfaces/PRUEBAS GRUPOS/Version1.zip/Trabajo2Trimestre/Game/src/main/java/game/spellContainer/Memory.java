package game.spellContainer;

public class Memory extends Knowledge{
}
