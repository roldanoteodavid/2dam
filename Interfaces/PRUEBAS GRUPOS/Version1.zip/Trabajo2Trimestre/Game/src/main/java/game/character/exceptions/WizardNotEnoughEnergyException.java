package game.character.exceptions;

public class WizardNotEnoughEnergyException extends Throwable {
}
