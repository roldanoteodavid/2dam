module CargarXML {
    exports LoadXML;
    exports LoadXML.loadXMLImpl;

    requires Game;
    requires java.xml;
}