package LoadXML;

import game.demiurge.Demiurge;

public interface LoadXml {
    Demiurge load(String filePath);
}
