module Save {
    exports saveTXT.saveTXTImpl;
    exports saveTXT;
    exports saveXML.saveXMLImpl;
    exports saveXML;
    requires Game;
    requires java.xml;
}