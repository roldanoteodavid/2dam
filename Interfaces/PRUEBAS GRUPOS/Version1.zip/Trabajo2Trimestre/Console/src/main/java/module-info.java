module Console {
    requires Game;
    requires Save;
    exports loaderManual;
    exports WizardNigthmare;
}