package saveXML;

import game.demiurge.Demiurge;

public interface SaveXML {
    void saveDemiurge(Demiurge demiurge,String filePath);
}
