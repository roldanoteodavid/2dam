module Save {
    requires java.xml;
    requires game;
}