package load;

import game.demiurge.Demiurge;

public interface LoadXml {
    Demiurge load(String filePath);
}
