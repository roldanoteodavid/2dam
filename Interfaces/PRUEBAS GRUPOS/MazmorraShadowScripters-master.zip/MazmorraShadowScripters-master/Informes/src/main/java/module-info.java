module Informes {
    requires game;
    requires jasperreports;
    requires java.xml;
}