package gui.pantallas.principal;

import gui.pantallas.common.BasePantallaController;

public class MenuJuegoController extends BasePantallaController {

    @Override
    public void principalLoaded() {
    }
}
