package game.objectContainer.exceptions;

public class ContainerInvalidExchangeException extends Throwable {
}
