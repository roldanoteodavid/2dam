package game.conditions;

public interface Condition {

    boolean check();
}
