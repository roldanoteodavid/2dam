package game;

public interface Interactive {

    void configure();

    void start();
}
