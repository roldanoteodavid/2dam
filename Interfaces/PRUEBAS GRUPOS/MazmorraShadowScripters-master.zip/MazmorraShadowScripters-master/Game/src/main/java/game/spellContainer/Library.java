package game.spellContainer;

public class Library extends Knowledge{
}
