package game.character.exceptions;

public class WizardLifeOverMaxException extends Throwable {
}
