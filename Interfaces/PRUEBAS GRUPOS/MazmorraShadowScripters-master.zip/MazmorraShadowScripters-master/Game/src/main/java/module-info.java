module game {
    exports game.demiurge.exceptions;
    exports game.demiurge;
    exports game.character.exceptions;
    exports game.dungeon;
    exports game.util;
    exports game.objectContainer;
    exports game.objectContainer.exceptions;
    exports game.spellContainer;
    exports game;
    exports game.character;
    exports game.conditions;
    exports game.object;
    exports game.spell;
exports game.actions;
}