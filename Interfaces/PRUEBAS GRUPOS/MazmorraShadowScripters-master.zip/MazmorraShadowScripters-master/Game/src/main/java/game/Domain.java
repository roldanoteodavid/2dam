package game;

import java.io.Serializable;

public enum Domain  implements Serializable {NONE, ELECTRICITY, AIR, FIRE, LIFE, ENERGY, JUMP}
