module CargaTXT {
    requires game;
}