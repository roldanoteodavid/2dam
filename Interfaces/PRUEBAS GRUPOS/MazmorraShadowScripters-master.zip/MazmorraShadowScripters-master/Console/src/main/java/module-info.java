module console {
    requires game;
    opens console;
    exports console;
}