module CargarTXT {
    exports LoadTXT;
    exports LoadTXT.loadTXTImpl;
    requires Game;
}