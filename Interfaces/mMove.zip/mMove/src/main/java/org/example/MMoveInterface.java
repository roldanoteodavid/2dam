package org.example;

import org.example.model.Room;

import java.util.List;

public interface MMoveInterface {

    void setRooms(List<Room> rooms);

    void loadRoom(Room room);
}
