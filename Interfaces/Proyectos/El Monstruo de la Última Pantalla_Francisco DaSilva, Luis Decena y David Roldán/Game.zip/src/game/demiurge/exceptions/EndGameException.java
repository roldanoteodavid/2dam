package game.demiurge.exceptions;

public class EndGameException extends Throwable {
}
