package game.demiurge.exceptions;

public class ExitException extends Throwable {
}
