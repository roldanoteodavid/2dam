package game.conditions;

public interface Condition {

    public boolean check();
}
