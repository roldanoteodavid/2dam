package game.dungeon.xml;

public class DungeonXML {
}
