package game.conditions;

public class SimpleCondition implements Condition{

    @Override
    public boolean check() { return true; }
}
