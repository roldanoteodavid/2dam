package game.util;

public class ValueUnderMinException extends Throwable {
}
