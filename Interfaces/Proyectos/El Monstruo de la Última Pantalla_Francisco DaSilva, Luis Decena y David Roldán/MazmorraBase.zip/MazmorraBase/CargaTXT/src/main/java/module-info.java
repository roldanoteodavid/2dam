module CargaTXT {
    requires Game;
}