module CargaXML {
    requires Game;
}