package org.example;

import game.dungeon.Dungeon;

public interface LeerDungeonXML {
    public Dungeon getDungeonfromXML();
}
